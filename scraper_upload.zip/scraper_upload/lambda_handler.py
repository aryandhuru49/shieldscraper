import json
import boto3
import os

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings

from job_spider import JobSpider  # 👈 Update this import to wherever your Spider is

s3 = boto3.client('s3')
RAW_BUCKET = os.environ['RAW_BUCKET']

def lambda_handler(event, context):
    try:
        # 1. Setup Crawler
        process = CrawlerProcess(get_project_settings())
        spider = JobSpider()
        process.crawl(spider)
        process.start()

        # 2. After crawling, get the data
        scraped_results = spider.scraped_data

        # 3. Upload to S3
        filename = "scraped_soccer_stats.json"
        s3.put_object(
            Bucket=RAW_BUCKET,
            Key=f"scrapes/{filename}",
            Body=json.dumps(scraped_results),
            ContentType='application/json'
        )

        return {
            'statusCode': 200,
            'body': f'Successfully scraped and stored {len(scraped_results)} records!'
        }

    except Exception as e:
        print(str(e))
        raise
